[![DeepScan grade](https://deepscan.io/api/teams/14511/projects/17640/branches/409616/badge/grade.svg)](https://deepscan.io/dashboard#view=project&tid=14511&pid=17640&bid=409616)
[![Dependency Status](https://david-dm.org/biaw/instatus-bot.svg)](https://david-dm.org/biaw/instatus-bot)
[![GitHub Issues](https://img.shields.io/github/issues-raw/biaw/instatus-bot.svg)](https://github.com/biaw/instatus-bot/issues)
[![GitHub Pull Requests](https://img.shields.io/github/issues-pr-raw/biaw/instatus-bot.svg)](https://github.com/biaw/instatus-bot/pulls)
[![License](https://img.shields.io/github/license/biaw/instatus-bot.svg)](https://github.com/biaw/instatus-bot/blob/master/LICENSE)
[![Discord Support](https://img.shields.io/discord/449576301997588490.svg)](https://promise.solutions/support)

# Instatus Manager

Instatus Manager is a bot that can manage instatus.com status pages.

## Suggestions, bugs, feature requests

Want to contribute? Great, we love that! Please take your time on [opening a new issue](https://github.com/biaw/instatus-bot/issues/new).

## Contributors

You can see all contributors and their GitHub-profiles [here](https://github.com/biaw/instatus-bot/graphs/contributors).

## Self-hosting
We do not recommend self-hosting the bot, but it's always an option. To selfhost the bot yourself, you need to have:
* Node - confirmed working on v14.17.1
* npm - comes with Node, the version shouldn't really matter
* A Discord bot token
* A clone of the source code, this can be found [here](https://github.com/biaw/instatus-bot) and needs to be extracted to a folder.

We will have to do this once:
* Rename `config.example.js` to `config.js`, and fill in the values. The config file is commented so you shouldn't get lost.
* Do `npm i` inside the folder, and wait for it to finish.

After all this, start the bot with `npm run start`.

> ### ⚠ Warning 
> There is literally no warranty if you self-host Countr, and we will not help you set it up either. If you wish to set the bot up yourself, we expect you have well enough knowledge in Node.js. We still recommend using the original bot.

## License

We use the GNU GPLv3-license.

> You may copy, distribute and modify the software as long as you track changes/dates in source files. Any modifications to or software including (via compiler) GPL-licensed code must also be made available under the GPL along with build & install instructions.

Fetched from [TLDRLegal](https://tldrlegal.com/license/gnu-general-public-license-v3-(gpl-3)), please also read the [license](https://github.com/biaw/instatus-bot/blob/master/LICENSE) if you plan on using the source code. This is only a short summary. Please also take note of that we are not forced to help you, and we won't help you host it yourself as we do not recommend you doing so.