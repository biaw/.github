module.exports = {
  token: "discord bot token", // https://discord.com/developers/applications
  oauth: {
    clientId: "discord bot id", // https://discord.com/developers/applications/:id/oauth2
    clientSecret: "discord bot secret" // https://discord.com/developers/applications/:id/oauth2
  },
  subscriberEmail: "void@but-it-actually.works", // just a placeholder for webhook subscribers, for some reason they require this
  color: 0x00B093, // brand color, used in embeds etc. hex code after "0x"
  port: 5050, // webserver port
  url: "http://localhost:5050", // an url starting with http(s) and doesn't end with a slash. can be localhost but OAuth2 will only work locally then
  paths: { // leave this unless you know what you're doing
    subscriberWebhook: "/api/subscriberWebhook/:id/:token",
    createWebhook: "/api/createWebhook"
  }
};