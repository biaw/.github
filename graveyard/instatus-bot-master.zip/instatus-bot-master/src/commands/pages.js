module.exports = {
  description: "Get all the status pages you have access to",
  requireKey: true
};

const instatus = require("../utils/instatus"), { emojis } = require("../database"), config = require("../../config");

module.exports.execute = async (interaction,  _, __, { key }) => {
  const pages = await instatus("GET", "/pages", key);
  interaction.reply({
    content: `${emojis.get("success")} Here's a list of status pages you have access to manage.`,
    embeds: [
      {
        color: config.color,
        fields: [
          {
            name: "Name",
            value: pages.map(p => `[${p.name}](http://${p.customDomain || `${p.subdomain}.instatus.com`})`).join("\n"),
            inline: true
          },
          {
            name: "ID",
            value: pages.map(p => `\`${p.id}\``).join("\n"),
            inline: true
          }
        ]
      }
    ],
    ephemeral: true
  });
};