module.exports = {
  description: "Add your API token to the bot to get started! (Command is hidden)",
  options: [
    {
      type: 3,
      name: "key",
      description: "The API key, you can find it here: https://instatus.com/app/developer",
      required: true
    }
  ]
};

const instatus = require("../utils/instatus"), { users, emojis } = require("../database");

module.exports.execute = async (interaction, { user }, { key }) => instatus("GET", "/user", key)
  .then(data => {
    data.key = key;
    users.set(user.id, data);
    interaction.reply({
      content: `${emojis.get("success")} Welcome aboard${data.name ? ", **${data.name}**" : ""}! (\`${data.email}\`)`,
      ephemeral: true
    });
  }).catch(err => interaction.reply({
    content: `${emojis.get("error")} This API key gave an error: \`${err.message}\``,
    ephemeral: true
  }));
