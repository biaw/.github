module.exports = {
  description: "Set the default status page for this server",
  requireKey: true,
  requirePermission: true,
  options: [
    {
      type: 3,
      name: "page_id",
      description: "The page ID of the status page you want to set as the default one. You can find this with `/pages`",
      required: true
    }
  ]
};

const instatus = require("../utils/instatus"), { defaults, emojis } = require("../database");

module.exports.execute = async (interaction, { guild }, { page_id }, { key }) => {
  const pages = await instatus("GET", "/pages", key), page = pages.find(p => p.id == page_id);
  if (page) {
    defaults.set(guild, page_id);
    interaction.reply({
      content: `${emojis.get("success")} This guild is now linked with the status page **${page.name}** <http://${page.customDomain || `${page.subdomain}.instatus.com`}>`
    });
  } else interaction.reply({
    content: `${emojis.get("error")} This page doesn't exist, or you don't have access to this status page.`,
    ephemeral: true
  });
};