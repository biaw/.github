module.exports = {
  description: "Get a list of the components on the status page"
};

const config = require("../../../config"), instatus = require("../../utils/instatus"), { emojis } = require("../../database"), { components: { formatted }, embeds: { fixed_width_image } } = require("../../constants"), { predicates, objects } = require("friendly-words");

module.exports.execute = async (interaction, _, __, { key, page, buttonCallbacks }) => instatus("GET", `/${page}/components`, key)
  .then(components => {
    components = components.sort((a, b) => (a.order || 0) - (b.order || 0)).sort((a, b) => {
      if (a.group && !b.group) return 1;
      if (!a.group && b.group) return -1;
      return 0;
    });
    const list = {};
    for (const com of components) {
      if (com.group) {
        if (!list[com.group.id]) list[com.group.id] = { name: com.group.name, components: {} };
        list[com.group.id].components[com.id] = { name: com.name, status: com.status };
      } else list[com.id] = { name: com.name, status: com.status };
    }
    
    const listNames = [], listIDs = [];
    for (const id in list) {

      const data = list[id];
      if (data.components) {
        listNames.push(`${emojis.get("component_group")} **${data.name.slice(0, 30)}**${data.name.length > 30 ? "..." : ""}`);
        listIDs.push(id);
        for (const com_id in data.components) {
          listIDs.push(com_id);
          listNames.push(`> ${formatted(data.components[com_id])}`);
        }
      } else {
        listNames.push(formatted(data));
        listIDs.push(id);
      }
    }

    let embeds = [], current = {
      color: config.color,
      fields: [
        {
          name: "Components",
          value: "",
          inline: true
        },
        {
          name: "IDs",
          value: "",
          inline: true
        }
      ],
      image: { url: fixed_width_image }
    };
    while (listNames.length) {
      const next = [ listNames.shift(), listIDs.shift() ];
      if (current.fields[0].value.split("\n").length >= 15) {
        embeds.push(current);
        current = {
          color: config.color,
          fields: [
            {
              name: "Components",
              value: "",
              inline: true
            },
            {
              name: "IDs",
              value: "",
              inline: true
            }
          ],
          image: { url: fixed_width_image }
        };
      }

      current.fields[0].value += "\n" + next[0];
      current.fields[1].value += "\n" + next[1];
    }
    embeds.push(current);

    if (embeds.length == 1) interaction.reply({
      content: `${emojis.get("success")} Here's a list of the current components on the status page.`, embeds
    }); else {
      const custom_id = `${predicates[Math.floor(Math.random() * predicates.length)]}-${objects[Math.floor(Math.random() * objects.length)]}`;
      let i = 0;
      interaction.reply(createMessage(embeds, i, custom_id));
      buttonCallbacks.set(`${custom_id}:previous`, interaction => {
        i -= 1;
        if (i < 0) i = 0;
        interaction.update(createMessage(embeds, i, custom_id));
      });
      buttonCallbacks.set(`${custom_id}:next`, interaction => {
        i += 1;
        if (i > embeds.length - 1) i = embeds.length - 1;
        interaction.update(createMessage(embeds, i, custom_id));
      });
    }
  });

function createMessage(embeds, current, custom_id) {
  return {
    content: `${emojis.get("success")} Here's a list of the current components on the status page.`,
    embeds: [ Object.assign(embeds[current], { footer: { text: `Page ${current + 1} of ${embeds.length}` }}) ],
    components: [ { type: 1, components: [
      {
        type: 2,
        style: 2,
        emoji: {
          id: null,
          name: "◀"
        },
        custom_id: `${custom_id}:previous`,
        disabled: current == 0
      },
      {
        type: 2,
        style: 2,
        emoji: {
          id: null,
          name: "▶"
        },
        custom_id: `${custom_id}:next`,
        disabled: current == embeds.length - 1
      }
    ]}]
  };
}