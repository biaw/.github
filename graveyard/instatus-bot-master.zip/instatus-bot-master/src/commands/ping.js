module.exports = {
  description: "Ping the bot"
};

const { emojis } = require("../database");

module.exports.execute = async (interaction, { client }) => {
  const start = Date.now();
  await interaction.defer();
  interaction.editReply(`${emojis.get("connection")} Server latency is \`${Date.now() - start}ms\`, API latency is \`${client.ws.ping}ms\`.`);
};