module.exports = {
  description: "Set up a webhook to receive incident and maintenance updates",
  requireAccess: true,
  options: [
    // method, role ping, incident messages, maintenance messages
    {
      type: 3,
      name: "method",
      description: "The style of the webhook",
      choices: [
        { name: "Individual messages for incident and maintenance updates", value: "individual" },
        { name: "A merged message per incident or maintenance", value: "merge-keep" },
        { name: "A merged message per incident or maintenance, but reposted", value: "merge-repost" }
      ]
    },
    {
      type: 8,
      name: "role",
      description: "The role you want to ping"
    },
    {
      type: 5,
      name: "incidents",
      description: "Whether you want incident updates or not (Default is true)"
    },
    {
      type: 5,
      name: "maintenances",
      description: "Whether you want maintenance updates or not (Default is true)"
    }
  ]
};

const config = require("../../config"), { emojis } = require("../database"), oauth = require("../utils/oauth"), { predicates, objects } = require("friendly-words");
const instatus = require("../utils/instatus");

module.exports.execute = async (interaction, _, { method, role, incidents, maintenances }, { key, page }) => {

  const identifier = `${predicates[Math.floor(Math.random() * predicates.length)]}-${objects[Math.floor(Math.random() * objects.length)]}`;
  queue.set(identifier, (id, token, channel_id) =>
    instatus("POST", `/${page}/subscribers`, key, {
      webhook: config.url + config.paths.subscriberWebhook.replace(":id", id).replace(":token", token) + "?" + [
        method ? `method=${method}` : null,
        role ? `role=${role}` : null,
        incidents ? `incidents=${incidents}` : null,
        maintenances ? `maintenances=${maintenances}` : null
      ].filter(l => l).join("&"),
      webhookEmail: config.subscriberEmail,
      all: true
    })
      .then(() => interaction.editReply(`${emojis.get("success")} I've linked this server's status page with <#${channel_id}>! To delete it, simply remove the webhook from the channel again. You can also move the webhook around. If you want to change how the webhook looks, please recreate the webhook.`))
      .catch(e => {
        console.log(e);
        interaction.editReply(`${emojis.get("error")} Something went wrong, can you try again?`);
      })
  );

  interaction.reply({
    content: `${emojis.get("channelfollow")} Create a webhook: <${oauth.generateAuthUrl({
      scope: "webhook.incoming",
      redirectUri: config.url + config.paths.createWebhook,
      state: identifier
    })}>`,
    ephemeral: true
  });
};

const queue = new Map();
module.exports.queue = queue;