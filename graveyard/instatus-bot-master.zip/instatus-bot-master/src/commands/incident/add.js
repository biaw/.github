module.exports = {
  description: "Create an incident on the status page",
  requireAccess: true,
  options: [
    {
      type: 3,
      name: "title",
      description: "The title of the incident",
      required: true
    },
    {
      type: 3,
      name: "description",
      description: "The description of the incident",
      required: true
    },
    {
      type: 3,
      name: "state",
      description: "The state of the incident, defaults to \"Investigating\"",
      choices: Object.keys(require("../../constants").incidentStatus).map(value => ({
        name: require("../../constants").incidentStatus[value].name, value
      }))
    }
  ]
};
const config = require("../../../config"), instatus = require("../../utils/instatus"), { emojis } = require("../../database"), { incidentStatus, components: { formatted, status, emoji }, embeds: { fixed_width_image, zero_width_space }} = require("../../constants"), { predicates, objects } = require("friendly-words");

module.exports.execute = async (interaction, _, { title, description, state = "INVESTIGATING" }, { key, page, buttonCallbacks }) => instatus("GET", `/${page}/components`, key)
  .then(components => {
    components = components.sort((a, b) => (a.order || 0) - (b.order || 0)).sort((a, b) => {
      if (a.group && !b.group) return 1;
      if (!a.group && b.group) return -1;
      return 0;
    });

    const list = {};
    for (const com of components) {
      if (com.group) {
        if (!list[com.group.id]) list[com.group.id] = { name: com.group.name, components: {} };
        list[com.group.id].components[com.id] = { name: com.name, status: com.status };
      } else list[com.id] = { name: com.name, status: com.status };
    }
    
    const coms = [];
    for (const id in list) {
      const data = list[id];
      if (data.components) {
        coms.push({
          name: `${emojis.get("component_group")} **${data.name.slice(0, 30)}**${data.name.length > 30 ? "..." : ""}`, rawName: data.name, id, group: true, components: Object.keys(data.components)
        });
        for (const com_id in data.components)
          coms.push({
            name: `> ${formatted(data.components[com_id])}`, rawName: data.components[com_id].name, id: com_id, status: data.components[com_id].status
          });
      } else coms.push({
        name: formatted(data), rawName: data.name, id, status: data.status
      });
    }
    
    const listSplit = [], copy = JSON.parse(JSON.stringify(coms));
    while (copy.length) listSplit.push(copy.splice(0, 15));

    let selected = 0, changes = {}, custom_id = `${predicates[Math.floor(Math.random() * predicates.length)]}-${objects[Math.floor(Math.random() * objects.length)]}`;
    interaction.reply(createMessage(listSplit, selected, custom_id, changes, coms, title, description, state));

    buttonCallbacks.set(`${custom_id}:prev+`, interaction => {
      selected -= 15;
      if (selected < 0) selected = 0;
      interaction.update(createMessage(listSplit, selected, custom_id, changes, coms, title, description, state));
    });

    buttonCallbacks.set(`${custom_id}:prev`, interaction => {
      selected -= 1;
      if (selected < 0) selected = 0;
      interaction.update(createMessage(listSplit, selected, custom_id, changes, coms, title, description, state));
    });
    
    buttonCallbacks.set(`${custom_id}:next`, interaction => {
      selected += 1;
      if (selected > coms.length - 1) selected = coms.length - 1;
      interaction.update(createMessage(listSplit, selected, custom_id, changes, coms, title, description, state));
    });
    
    buttonCallbacks.set(`${custom_id}:next+`, interaction => {
      selected += 15;
      if (selected > coms.length - 1) selected = coms.length - 1;
      interaction.update(createMessage(listSplit, selected, custom_id, changes, coms, title, description, state));
    });

    Object.keys(status).forEach(s => buttonCallbacks.set(`${custom_id}:${s}`, interaction => {
      if (coms[selected].group) coms[selected].components.forEach(c => changes[c] = s);
      else changes[coms[selected].id] = s;
      interaction.update(createMessage(listSplit, selected, custom_id, changes, coms, title, description, state));
    }));

    buttonCallbacks.set(`${custom_id}:unset`, interaction => {
      if (coms[selected].group) coms[selected].components.forEach(c => delete changes[c]);
      else delete changes[coms[selected].id];
      interaction.update(createMessage(listSplit, selected, custom_id, changes, coms, title, description, state));
    });

    buttonCallbacks.set(`${custom_id}:finish`, async interaction => {
      [...buttonCallbacks.keys()].filter(key => key.startsWith(custom_id)).forEach(key => buttonCallbacks.delete(key));
      interaction.editReply({
        content: (await Promise.all([
          interaction.update({
            content: `${emojis.get("blank")} Posting...`,
            embeds: [], components: []
          }),
          instatus("POST", `/${page}/incidents`, key, {
            name: title,
            message: description,
            components: Object.keys(changes),
            started: new Date(),
            status: state,
            notify: true,
            statuses: Object.keys(changes).map(id => ({ id, status: changes[id] }))
          })
            .then(() => `${emojis.get("success")} Incident has been created successfully!`)
            .catch(err => `${emojis.get("error")} I got an error when trying to create the incident: \`${err.message}\``)
        ]))[1],
      });
    });

    buttonCallbacks.set(`${custom_id}:cancel`, interaction => {
      [...buttonCallbacks.keys()].filter(key => key.startsWith(custom_id)).forEach(key => buttonCallbacks.delete(key));
      interaction.update({
        content: `${emojis.get("error")} Incident creation canceled by the user.`,
        embeds: [], components: [] // remove embeds and components
      });
    });
  });

function createMessage(lists, selected, custom_id, changes, components, title, description, state) {
  const page = Math.floor(selected / 15), list = lists[page], listSelected = selected % 15;

  console.log(page, selected, listSelected, list[listSelected]);

  const newComponentList = components.filter(com => Object.keys(changes).includes(com.id));
  for (const i of newComponentList) i.status = changes[i.id];

  const buttons = [
      ...Object.keys(status).map(s => ({
        type: 2,
        style: 1,
        emoji: componentEmoji(status[s].id),
        custom_id: `${custom_id}:${s}`,
        disabled: (changes[list[listSelected].id] || list[listSelected].status) == s
      })).filter(button => !button.disabled),
      {
        type: 2,
        style: 1,
        label: list[listSelected].group ? "Reset all group components' statuses" : "Reset component status",
        custom_id: `${custom_id}:unset`,
        disabled: !changes[list[listSelected].id] && !(list[listSelected].components || []).find(c => changes[c])
      },
      {
        type: 2,
        style: 3,
        label: "Finish and send",
        custom_id: `${custom_id}:finish`,
        disabled: Object.keys(changes).length == 0
      },
      {
        type: 2,
        style: 4,
        label: "Cancel",
        custom_id: `${custom_id}:cancel`
      }
    ], buttonRows = [];

  while (buttons.length) buttonRows.push({
    type: 1,
    components: buttons.splice(0, 5)
  });

  return {
    content: `${emojis.get("document")} Edit your incident before sending.`,
    embeds: [
      {
        color: incidentStatus[state].color,
        fields: [
          {
            name: `${incidentStatus[state].name}: ${title}`,
            value: description,
            inline: true
          },
          {
            name: "Components",
            value:
              zero_width_space + // if no components are selected
              newComponentList.slice(0, 5).map(c => formatted({ name: c.rawName, status: c.status })).join("\n") +
              (newComponentList.length > 5 ? `\n${zero_width_space}    *+ ${newComponentList.length - 5} more*` : ""),
            inline: true
          }
        ],
        image: { url: fixed_width_image }
      },
      {
        color: config.color,
        fields: [
          {
            name: "Components",
            value: list.map(l => l.name).join("\n"),
            inline: true
          },
          {
            name: "New statuses",
            value: zero_width_space + list.map((com, index) => 
              index == listSelected ?
                (changes[com.id] ? emoji(changes[com.id]) : emojis.get("blank")) + emojis.get("selected") :
                (changes[com.id] ? emoji(changes[com.id]) : "")
            ).join("\n"),
            inline: true
          }
        ],
        image: { url: fixed_width_image }
      }
    ],
    components: [
      {
        type: 1,
        components: [
          {
            type: 2,
            style: 2,
            emoji: {
              id: null,
              name: "⏮️"
            },
            custom_id: `${custom_id}:prev+`,
            disabled: selected == 0
          },
          {
            type: 2,
            style: 2,
            emoji: {
              id: null,
              name: "⬅️"
            },
            custom_id: `${custom_id}:prev`,
            disabled: selected == 0
          },
          {
            type: 2,
            style: 2,
            emoji: {
              id: null,
              name: "➡️"
            },
            custom_id: `${custom_id}:next`,
            disabled: selected == components.length - 1
          },
          {
            type: 2,
            style: 2,
            emoji: {
              id: null,
              name: "⏩"
            },
            custom_id: `${custom_id}:next+`,
            disabled: selected == components.length - 1
          }
        ]
      },
      ...buttonRows
    ]
  };
}

function componentEmoji(emoji) {
  const e = emojis.get(emoji), name = e.replace("<:", "").split(":")[0], id = e.replace("<:", "").split(":")[1].replace(">", "");
  return { id, name };
}