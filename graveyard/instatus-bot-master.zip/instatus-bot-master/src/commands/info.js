module.exports = {
  description: "Get info about the bot"
};

const os = require("os"), platform = `${os.type()} (${os.release()})`, djsversion = require("../../package.json").dependencies["discord.js"], config = require("../../config");

let memory = 0, memoryUsage = "0MB", nextUpdate = Date.now();

module.exports.execute = async (interaction, { client }) => {
  if (nextUpdate < Date.now()) {
    nextUpdate = Date.now() + 300000;

    memory = process.memoryUsage().heapUsed / 1048576; // 1024*1024
    if (memory >= 1024) memoryUsage = (memory / 1024).toFixed(2) + "GB";
    else memoryUsage = memory.toFixed(2) + "MB";
  }

  interaction.reply({
    embeds: [{
      title: `Bot Information - ${client.user.tag}`,
      description: "Instatus Manager is a bot that can manage instatus.com status pages.",
      color: config.color,
      fields: [
        {
          name: "💠 Host",
          value: [
            `**OS**: \`${platform}\``,
            `**Library**: \`${djsversion.startsWith("github:") ? djsversion : `discord.js${djsversion}`}\``,
            `**Memory Usage**: \`${memoryUsage}\``
          ].join("\n"),
          inline: true
        },
        {
          name: "🌐 Links",
          value: [
            `**Invite me:** [https://discord.com/api/oauth2/authorize?...](https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=applications.commands)`,
            "**Source Code**: https://github.com/biaw/instatus-bot",
            "**Support Server**: https://promise.solutions/support"
          ].join("\n"),
          inline: false
        }
      ]
    }],
    ephemeral: true
  });
};