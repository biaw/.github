module.exports = {
  description: "Add a team member to the status page",
  requireAccess: true,
  options: [
    {
      type: 6,
      name: "member",
      description: "The member you want to remove, this will work if they've linked their Instatus account"
    },
    {
      type: 3,
      name: "team_member_id",
      description: "The team member's ID you want to remove, you can find this with `/team list`"
    }
  ]
};

const instatus = require("../../utils/instatus"), { users, emojis } = require("../../database");

module.exports.execute = async (interaction, _, { member, team_member_id }, { key, page }) => {
  if (!member && !team_member_id) return interaction.reply({
    content: `${emojis.get("error")} You need to supply me with either a member or a user ID with this command, try again.`,
    ephemeral: true
  });

  if (member) {
    const user = users.get(member);
    if (!user) return interaction.reply({
      content: `${emojis.get("error")} This member has not linked their Instatus profile yet, please use their member ID or ask them to link first.`,
      ephemeral: true
    });
    team_member_id = user.id;
  }

  instatus("DELETE", `/${page}/team/${team_member_id}`, key)
    .then(() => interaction.reply({
      content: `${emojis.get("success")} I've removed the user from the status page.`
    }))
    .catch(err => interaction.reply({
      content: `${emojis.get("error")} This request gave me an error: \`${console.log(err) || err.message}\``,
      ephemeral: true
    }));
};