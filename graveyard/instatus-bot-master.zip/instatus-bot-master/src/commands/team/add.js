module.exports = {
  description: "Add a team member to the status page",
  requireAccess: true,
  options: [
    {
      type: 6,
      name: "member",
      description: "The member you want to add, this will work if they've linked their Instatus account"
    },
    {
      type: 3,
      name: "email",
      description: "The email you want to add"
    }
  ]
};

const instatus = require("../../utils/instatus"), { users, emojis } = require("../../database");

module.exports.execute = async (interaction, _, { member, email }, { key, page }) => {
  if (!member && !email) return interaction.reply({
    content: `${emojis.get("error")} You need to supply me with either a member or an email with this command, try again.`,
    ephemeral: true
  });

  if (member) {
    const user = users.get(member);
    if (!user) return interaction.reply({
      content: `${emojis.get("error")} This member has not linked their Instatus profile yet, please use their email or ask them to link first.`,
      ephemeral: true
    });
    email = user.email;
  }

  instatus("POST", `/${page}/team`, key, { email })
    .then(() => interaction.reply({
      content: `${emojis.get("success")} I've invited \`${email}\`, tell them to check their email!`
    }))
    .catch(err => interaction.reply({
      content: `${emojis.get("error")} This request gave me an error: \`${console.log(err) || err.message}\``,
      ephemeral: true
    }));
};