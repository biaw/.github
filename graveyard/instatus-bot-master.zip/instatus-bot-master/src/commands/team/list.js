module.exports = {
  description: "Get a list of the members added to the status page",
  requireAccess: true
};

const instatus = require("../../utils/instatus"), { users, emojis } = require("../../database"), config = require("../../../config");

module.exports.execute = async (interaction, _, __, { key, page }) => {
  const team = await instatus("GET", `/${page}/team`, key).catch(e => { console.log(e); return null; });
  interaction.reply({
    content: `${emojis.get("success")} Here's a list of the current members of the status page.`,
    embeds: [
      {
        color: config.color,
        fields: [
          {
            name: "Team member",
            value: team.map(({ user }) => {
              const match = users.getDiscord(user.id);
              if (match) return `<@${match}>`;
              else return user.name || (user.slug ? `\`${user.slug}\`` : null) || "No name";
            }).join("\n"),
            inline: true
          },
          {
            name: "Email",
            value: team.map(({ user }) => `\`${user.email}\``).join("\n"),
            inline: true
          },
          {
            name: "Team member ID",
            value: team.map(({ id }) => `\`${id}\``).join("\n"),
            inline: true
          }
        ]
      }
    ]
  });
};