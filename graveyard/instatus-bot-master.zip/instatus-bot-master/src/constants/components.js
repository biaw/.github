const { emojis } = require("../database");

module.exports.status = {
  OPERATIONAL: {
    name: "Operational",
    id: "operational",
    color: 0x0
  },
  UNDERMAINTENANCE: {
    name: "Under maintenance",
    id: "under_maintenance",
    color: 0x0
  },
  DEGRADEDPERFORMANCE: {
    name: "Degraded performance",
    id: "degraded_performance",
    color: 0x0
  },
  PARTIALOUTAGE: {
    name: "Partial outage",
    id: "partial_outage",
    color: 0x0
  },
  MINOROUTAGE: {
    name: "Minor outage",
    id: "minor_outage",
    color: 0x0
  },
  MAJOROUTAGE: {
    name: "Major outage",
    id: "major_outage",
    color: 0x0
  }
};

module.exports.emoji = status => emojis.get(module.exports.status[status] ? module.exports.status[status].id : "blank");

module.exports.formatted = (com, max = 20) => `${module.exports.emoji(com.status)} **${com.name.slice(0, max)}**${com.name.length > max ? "..." : ""}`;

