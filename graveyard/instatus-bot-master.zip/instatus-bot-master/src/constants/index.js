module.exports = {
  components: require("./components"),
  embeds: require("./embeds"),

  incidentStatus: {
    INVESTIGATING: {
      name: "Investigating",
      color: 0xdc123d
    },
    IDENTIFIED: {
      name: "Identified",
      color: 0xed8936
    },
    MONITORING: {
      name: "Monitoring",
      color: 0xecc94b
    },
    RESOLVED: {
      name: "Resolved",
      color: 0x00b093
    }
  },
  maintenanceStatus: {
    NOTSTARTEDYET: {
      name: "Not started yet",
      color: 0x272829
    },
    INPROGRESS: {
      name: "In progress",
      color: 0xecc94b
    },
    COMPLETED: {
      name: "Completed",
      color: 0x00b093
    }
  }
};