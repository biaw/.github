module.exports.fixed_width_image = "https://i.imgur.com/TFgZRO4.png";

module.exports.zero_width_space = "​";