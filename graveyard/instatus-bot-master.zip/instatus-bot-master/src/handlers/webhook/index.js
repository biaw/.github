const
  config = require("../../../config"),
  app = require("../../utils/express"),
  oauth = require("../../utils/oauth"),
  { paths } = require("../../../config"),
  processIncident = require("./incident"),
  processMaintenance = require("./maintenance"),
  { queue } = require("../../commands/subscribe");

module.exports = async client => {
  app.post(paths.subscriberWebhook, (request, response) => client.fetchWebhook(request.params.id, request.params.token)
    .then(async webhook => {
      const {
          method = "merge-edit",
          role = null,
          incidents = true,
          maintenances = true
        } = request.query, {
          incident,
          maintenance
        } = request.body;

      response.sendStatus(200);

      if (incident) incident.incident_updates = incident.incident_updates.sort((a, b) => 
        (new Date(a.created_at)).getTime() - (new Date(b.created_at)).getTime()
      ); else if (maintenance) maintenance.maintenance_updates = maintenance.maintenance_updates.sort((a, b) => 
        (new Date(a.created_at)).getTime() - (new Date(b.created_at)).getTime()
      );

      if (incidents && incident) return processIncident(webhook, request.body, method, role);
      if (maintenances && maintenance) return processMaintenance(webhook, request.body, method, role);
    })
    .catch(e => {
      console.log(e);
      response.sendStatus(500);
    }));
  
  app.get(paths.createWebhook, (request, response) => {
    if (!request.query.code) return response.sendStatus(403);
    if (!request.query.state || !queue.has(request.query.state)) return response.sendStatus(400);
    oauth.tokenRequest({
      code: request.query.code,
      scope: "webhook.incoming",
      grantType: "authorization_code",
      redirectUri: config.url + config.paths.createWebhook
    }).then(({ webhook: { id, token, channel_id, guild_id } }) => {
      response.redirect(`${client.options.http.api.replace("/api", "")}/channels/${guild_id}/${channel_id}`);
      queue.get(request.query.state)(id, token, channel_id);
      queue.delete(request.query.state);
    }).catch(e => {
      console.log(e);
      response.sendStatus(500);
    });
  });
};