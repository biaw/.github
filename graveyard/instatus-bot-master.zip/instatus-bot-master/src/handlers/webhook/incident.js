const { webhookStorage } = require("../../database"), { incidentStatus, components: { formatted }, embeds: { fixed_width_image } } = require("../../constants");

module.exports = async (webhook, { incident }, method, role) => { console.log(incident);
  if (method == "individual") {
    // update existing incident messages
    for (const update of incident.incident_updates) {
      const m = webhookStorage.get(`${webhook.id}-${update.id}-individual`);
      if (m && m.id) {
        const id = m.id;
        delete m.username;
        delete m.id;
        const newField = {
          name: incidentStatus[update.status].name,
          value: update.markdown,
          inline: true
        };
        if (JSON.stringify(m.embeds[0].fields[0]) !== JSON.stringify(newField)) {
          m.embeds[0].fields[0] = newField;
          await webhook.editMessage(id, m);
        }
      }
    }

    // send new incident message if it doesn't exist
    const update = incident.incident_updates[incident.incident_updates.length - 1];
    if (!webhookStorage.get(`${webhook.id}-${update.id}-individual`)) {
      const m = {
        username: incident.name.length >= 29 ? incident.name.split(0, 29) + "..." : incident.name,
        embeds: [{
          fields: [
            {
              name: incidentStatus[update.status].name,
              value: update.markdown,
              inline: true
            },
            {
              name: "Components",
              value: 
                incident.affected_components.slice(0, 5).map(ac => formatted(ac)).join("\n") +
                (incident.affected_components.length > 5 ? `\n* + ${incident.affected_components.length - 5} more` : ""),
              inline: true
            }
          ],
          color: incidentStatus[update.status].color,
          image: { url: fixed_width_image },
          timestamp: new Date(update.created_at).getTime()
        }]
      };

      if (role) Object.assign(m, {
        content: `<@&${role}>`,
        allowedMentions: { roles: [ role ] }
      });

      const sent = await webhook.send(m);

      m.id = sent.id;
      webhookStorage.set(`${webhook.id}-${update.id}-individual`, m);
    }
  } else if (method == "merge-repost" || method == "merge-keep") {
    const data = webhookStorage.get(`${webhook.id}-${incident.id}-merge`) || { embeds: {} }, m = {
      username: incident.name.length >= 29 ? incident.name.split(0, 29) + "..." : incident.name,
      embeds: await Promise.all(incident.incident_updates.map(async update => {
        const existing = webhookStorage.get(`${webhook.id}-${update.id}-merge-embed`), embed = existing || {
          fields: [
            {
              name: incidentStatus[update.status].name,
              value: update.markdown,
              inline: true
            },
            {
              name: "Components",
              value:
                incident.affected_components.slice(0, 5).map(ac => formatted(ac)).join("\n") +
                (incident.affected_components.length > 5 ? `\n* + ${incident.affected_components.length - 5} more` : ""),
              inline: true
            }
          ],
          color: incidentStatus[update.status].color,
          image: { url: fixed_width_image },
          timestamp: new Date(update.created_at).getTime()
        };
        if (!existing) webhookStorage.set(`${webhook.id}-${update.id}-merge-embed`, embed);
        return embed;
      }))
    };

    if (role) Object.assign(m, {
      content: `<@&${role}>`,
      allowedMentions: { roles: [ role ] }
    });

    let sent;
    if (!data.id) sent = await webhook.send(m);
    else if (method == "merge-keep") sent = await webhook.editMessage(data.id, m);
    else if (method == "merge-repost") sent = await webhook.send(m).then(output => {
      webhook.deleteMessage(data.id);
      return output;
    });

    m.id = sent.id;
    webhookStorage.set(`${webhook.id}-${incident.id}-merge`, m);
  }
};