const { webhookStorage } = require("../../database"), { maintenanceStatus, components: { formatted }, embeds: { fixed_width_image } } = require("../../constants");

module.exports = async (webhook, { maintenance }, method, role) => { console.log(maintenance);
  if (method == "individual") {
    // update existing maintenance messages
    for (const update of maintenance.maintenance_updates) {
      const m = webhookStorage.get(`${webhook.id}-${update.id}-individual`);
      if (m && m.id) {
        const id = m.id;
        delete m.username;
        delete m.id;
        const newField = {
          name: maintenanceStatus[update.status].name,
          value: update.markdown,
          inline: true
        };
        if (JSON.stringify(m.embeds[0].fields[0]) !== JSON.stringify(newField)) {
          m.embeds[0].fields[0] = newField;
          await webhook.editMessage(id, m);
        }
      }
    }

    // send new maintenance message if it doesn't exist
    const update = maintenance.maintenance_updates[maintenance.maintenance_updates.length - 1];
    if (!webhookStorage.get(`${webhook.id}-${update.id}-individual`)) {
      const m = {
        username: maintenance.name.length >= 29 ? maintenance.name.split(0, 29) + "..." : maintenance.name,
        embeds: [{
          fields: [
            {
              name: maintenanceStatus[update.status].name,
              value: update.markdown,
              inline: true
            },
            {
              name: "Components",
              value: 
                maintenance.affected_components.slice(0, 5).map(ac => formatted(ac)).join("\n") +
                (maintenance.affected_components.length > 5 ? `\n* + ${maintenance.affected_components.length - 5} more` : ""),
              inline: true
            }
          ],
          color: maintenanceStatus[update.status].color,
          image: { url: fixed_width_image },
          timestamp: new Date(update.created_at).getTime()
        }]
      };

      if (role) Object.assign(m, {
        content: `<@&${role}>`,
        allowedMentions: { roles: [ role ] }
      });

      const sent = await webhook.send(m);

      m.id = sent.id;
      webhookStorage.set(`${webhook.id}-${update.id}-individual`, m);
    }
  } else if (method == "merge-repost" || method == "merge-keep") {
    const data = webhookStorage.get(`${webhook.id}-${maintenance.id}-merge`) || { embeds: {} }, m = {
      username: maintenance.name.length >= 29 ? maintenance.name.split(0, 29) + "..." : maintenance.name,
      embeds: await Promise.all(maintenance.maintenance_updates.map(async update => {
        const existing = webhookStorage.get(`${webhook.id}-${update.id}-merge-embed`), embed = existing || {
          fields: [
            {
              name: maintenanceStatus[update.status].name,
              value: update.markdown,
              inline: true
            },
            {
              name: "Components",
              value:
                maintenance.affected_components.slice(0, 5).map(ac => formatted(ac)).join("\n") +
                (maintenance.affected_components.length > 5 ? `\n* + ${maintenance.affected_components.length - 5} more` : ""),
              inline: true
            }
          ],
          color: maintenanceStatus[update.status].color,
          image: { url: fixed_width_image },
          timestamp: new Date(update.created_at).getTime()
        };
        if (!existing) webhookStorage.set(`${webhook.id}-${update.id}-merge-embed`, embed);
        return embed;
      }))
    };

    if (role) Object.assign(m, {
      content: `<@&${role}>`,
      allowedMentions: { roles: [ role ] }
    });

    let sent;
    if (!data.id) sent = await webhook.send(m);
    else if (method == "merge-keep") sent = await webhook.editMessage(data.id, m);
    else if (method == "merge-repost") sent = await webhook.send(m).then(output => {
      webhook.deleteMessage(data.id);
      return output;
    });

    m.id = sent.id;
    webhookStorage.set(`${webhook.id}-${maintenance.id}-merge`, m);
  }
};