const fs = require("fs"), { Permissions } = require("discord.js"), { join } = require("path"), { emojis, users, defaults } = require("../database"), config = require("../../config.js"), instatus = require("../utils/instatus");

const buttonCallbacks = new Map();

module.exports = async client => {
  // register commands
  (config.guild ?
    client.guilds.cache.get("850855855699525652").commands.set(commands) :
    client.application.commands.set(commands)
  ).then(() => console.log("Slash commands have been registered."));

  client.on("interaction", async interaction => {
    if (interaction.isButton()) {
      if (interaction.message.interaction.user.id !== interaction.user.id) interaction.reply({
        content: `${emojis.get("error")} Only ${interaction.message.interaction.user} can interact with this message.`, ephemeral: true
      }); else {
        const callback = buttonCallbacks.get(interaction.customID);
        if (callback) callback(interaction);
      }
    }
    if (!interaction.isCommand()) return;
    const
      command = commands.find(c => c.name == interaction.commandName),
      args = getSlashArgs(interaction.options),
      path = [
        command.name,
        ...(
          command.description == "Sub-command." ? [
            command.options.find(o => o.name == Object.keys(args)[0]).name,
            ...(
              command.options.find(o => o.name == Object.keys(args)[0]).description == "Sub-command." ? [
                command.options.find(o => o.name == Object.keys(args)[0]).options.find(o => o.name == Object.keys(Object.values(args)[0])[0]).name
              ] : []
            )
          ] : []
        )
      ], // remove nulls
      commandFile = require(`../commands/${path.join("/")}.js`);

    // check permission
    // todo: check discord permission
    if (commandFile.requireOwner && config.owner !== interaction.user.id) return interaction.reply({
      content: `${emojis.get("error")} This is a locked command, only the bot owner have access to this.`,
      ephemeral: true
    }); else if (commandFile.requirePermission && !(new Permissions(BigInt(interaction.member.permissions))).has("MANAGE_SERVER") && config.owner !== interaction.user.id) return interaction.reply({
      content: `${emojis.get("error")} This is an admin command, only admins of the server have access to this command.`,
      ephemeral: true
    });

    // check instatus access
    const entry = users.get(interaction.user.id), page = defaults.get(interaction.guildID);
    if (commandFile.requireKey || commandFile.requireAccess) {
      if (!entry) return interaction.reply({
        content: `${emojis.get("error")} You need to give me your API token to use this command, do \`/authenticate\`.`,
        ephemeral: true
      });

      const pages = await instatus("GET", "/pages", entry.key).catch(() => null);
      if (!pages) return interaction.reply({
        content: `${emojis.get("error")} Your API key is no longer working, redo \`/authenticate\` to fix the issue.`,
        ephemeral: true
      });

      if (commandFile.requireAccess) {
        if (!page) return interaction.reply({
          content: `${emojis.get("error")} This server doesn't have a page connected, get an administrator to link one!`,
          ephemeral: true
        });
        
        if (!pages.find(p => p.id == page)) return interaction.reply({
          content: `${emojis.get("error")} You don't have access to manage this status page, if this is a mistake then ask the owner to add you to the team!`,
          ephemeral: true
        });
      }
    }
    
    const info = Object.assign(entry || {}, {
      page, buttonCallbacks
    });

    commandFile.execute(interaction, {
      client,
      member: interaction.member,
      user: interaction.user,
      guild: interaction.guildID
    }, getActualSlashArgs(interaction.options), info);
  });
};

function getSlashArgs(options) { // to get the path as well as the args
  const args = {};
  for (const o of [...options.values()]) args[o.name] = o.options ? getSlashArgs(o.options) : o.value;
  return args;
}

function getActualSlashArgs(options) { // sends through to the command files
  if (!options.first()) return {};
  if (options.first().options) return getActualSlashArgs(options.first().options);
  else return getSlashArgs(options);
}

// loading commands
let commands = []; nestCommands("../commands").then(comm => commands = comm.map(c => { delete c.type; return c; }));

function nestCommands(relPath, layer = 0) {
  return new Promise(resolve => fs.readdir(join(__dirname, relPath), async (err, files) => {
    if (err) return console.log(err);
    const arr = [];
    for (const file of files) {
      if (file.endsWith(".js")) {
        const { description = "No description", options = [] } = require(`${relPath}/${file}`);
        arr.push({ name: file.split(".")[0], description, options, type: 1 });
      } else if (!file.includes(".")) {
        const options = await nestCommands(`${relPath}/${file}`, layer + 1);
        arr.push({ name: file, description: "Sub-command.", options, type: 2 });
      }
    }
    resolve(arr);
  }));
}