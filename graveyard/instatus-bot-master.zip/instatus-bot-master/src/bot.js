const
  Discord = require("discord.js"),
  config = require("../config"),
  commandHandler = require("./handlers/commands"),
  emojiHandler = require("./handlers/emojis"),
  webhookHandler = require("./handlers/webhook"),
  client = new Discord.Client({
    messageCacheLifetime: 30,
    messageSweepInterval: 60,
    allowedMentions: {},
    partials: [ "USER", "CHANNEL", "GUILD_MEMBER", "MESSAGE", "REACTION" ],
    intents: [ "GUILDS", "GUILD_EMOJIS" ]
  });

client.once("shardReady", async () => {
  console.log(`Ready as ${client.user.tag}!`);

  if (client.user.id !== config.oauth.clientId) {
    console.log("Logged in user is not the same as config.oauth.clientId, destroying the client.");
    client.destroy();
    process.exit();
  }

  if (!client.guilds.cache.size) console.log(`
    Hello 👋
    • Add the bot with this link: https://discord.com/oauth2/authorize?client_id=${client.user.id}&scope=applications.commands
    • Make sure these redirect URIs are configured on the application: ${[config.paths.createWebhook].map(path => config.url + path).join(", ")}
  `);

  await emojiHandler(client).then(() => console.log("Emoji server have been loaded"));
  commandHandler(client).then(() => console.log("Commands have been loaded"));
  webhookHandler(client);
});

client
  .on("error", err => console.log("Client error.", err))
  .on("rateLimit", rateLimitInfo => console.log("Rate limited.", JSON.stringify(rateLimitInfo)))
  .on("shardDisconnected", closeEvent => console.log("Disconnected.", closeEvent))
  .on("shardError", err => console.log("Error.", err))
  .on("shardReconnecting", () => console.log("Reconnecting."))
  .on("shardResume", (_, replayedEvents) => console.log(`Resumed. ${replayedEvents} replayed events.`))
  .on("warn", info => console.log("Warning.", info))
  .login(config.token);