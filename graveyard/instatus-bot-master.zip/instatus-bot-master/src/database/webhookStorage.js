const db = require("quick.db"), whStorage = new db.table("webhookStorage");

const set = (id, data) => whStorage.set(id, data);
const get = (id) => whStorage.get(id);
const del = (id) => whStorage.delete(id);

module.exports = { set, get, del };