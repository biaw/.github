const db = require("quick.db"), users = new db.table("users"), discords = new db.table("discords");

const set = (user_id, user_data) => {
  users.set(user_id, user_data);
  discords.set(user_data.id, user_id);
};
const get = (user_id) => users.get(user_id);
const getDiscord = (instatus_id) => discords.get(instatus_id);
const del = (user_id) => {
  const user_data = users.get(user_id);
  users.delete(user_id);
  discords.delete(user_data.id);
};

module.exports = { set, get, getDiscord, del };