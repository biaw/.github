const db = require("quick.db"), emojis = new db.table("emojis");

const set = (emoji_name, emoji) => emojis.set(emoji_name, emoji);
const get = (emoji_name) => emojis.get(emoji_name);
const del = (emoji_name) => emojis.delete(emoji_name);
const reset = () => {
  const all = emojis.all();
  for (const [ ID ] of all) emojis.delete(ID);
};

module.exports = { set, get, del, reset };