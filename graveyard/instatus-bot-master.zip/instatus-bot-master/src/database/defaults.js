const db = require("quick.db"), defaults = new db.table("defaults");

const set = (guild_id, page_id) => defaults.set(guild_id, page_id);
const get = (guild_id) => defaults.get(guild_id);
const del = (guild_id) => defaults.delete(guild_id);

module.exports = { set, get, del };