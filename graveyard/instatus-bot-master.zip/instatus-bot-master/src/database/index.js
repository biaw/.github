module.exports = {
  users: require("./users"),
  defaults: require("./defaults.js"),
  emojis: require("./emojis"),
  webhookStorage: require("./webhookStorage")
};

/* if we, in the future, want to change how we do databases then we can do that easily as it all goes through this file (and subfiles), instead of being directly accessed in the code itself. */