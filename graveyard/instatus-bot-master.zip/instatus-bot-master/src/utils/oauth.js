const config = require("../../config"), oauth = require("discord-oauth2");

module.exports = new oauth({
  clientId: config.oauth.clientId,
  clientSecret: config.oauth.clientSecret
});