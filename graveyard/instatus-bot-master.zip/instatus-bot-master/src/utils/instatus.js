const fetch = require("node-fetch");

module.exports = (method, path, key, body = {}) =>
  new Promise((resolve, reject) =>
    fetch(`https://api.instatus.com/v1${path}`, {
      method, headers: {
        "Authorization": `Bearer ${key}`,
        "Content-Type": "application/json"
      }, body: method == "GET" ? null : JSON.stringify(body)
    }).then(res => res.json()).then(data => data.error ? reject(data.error) : resolve(data)).catch(reject)
  );