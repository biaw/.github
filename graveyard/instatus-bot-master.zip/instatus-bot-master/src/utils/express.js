const express = require("express"), config = require("../../config");

module.exports = express();
module.exports.use(express.json());

module.exports.get("/", (_, response) => response.redirect(`https://discord.com/oauth2/authorize?client_id=${config.oauth.clientId}&scope=applications.commands`));

module.exports.listen(config.port);