---
name: 'Report a typo'
about: Create a report on a typo in the bot's code
labels: typo
assignees: promise
---

# Typo

Write a summary here. It can be as short as the short summary in the title, or longer.

## Screenshots

If you have screenshots, please upload these.