---
name: 'Feature Request'
about: Create a feature request on something you feel should be added to the bot
labels: feature_request
assignees: promise
---

# Feature request

Write a summary here. It can be as short as the short summary in the title, or longer.